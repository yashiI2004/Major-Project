import { useEffect, useMemo, useState } from "react";
import { Canvas, extend, ReactThreeFiber, useThree } from "@react-three/fiber";
import { useAreaStore } from "@/state/areaStore";
import { Html, Sky, Environment, Line, Edges } from "@react-three/drei";
import * as THREE from "three";
import { useActionStore } from "@/state/exportStore";
import { GLTFExporter } from "three/examples/jsm/Addons.js";
import Car from "./Car";
import instanceFleet from "@/api/axios";

const scale = 51000;

function getBuildingColor(tags: any) {
  return "#facc15";
}

function Building({
  shape,
  extrudeSettings,
  tags,
  onSelect,
}: {
  shape: THREE.Shape;
  extrudeSettings: any;
  tags: any;
  onSelect?: (data: any) => void;
}) {
  const [hovered, setHovered] = useState(false);
  const [clicked, setClicked] = useState(false);
  const buildingColor = getBuildingColor(tags);
  const roofHeight = Math.max(0.2, Math.min(0.6, extrudeSettings.depth * 0.02));
  const shapePoints = shape.getPoints();

  const minX = Math.min(...shapePoints.map((point) => point.x));
  const maxX = Math.max(...shapePoints.map((point) => point.x));
  const minY = Math.min(...shapePoints.map((point) => point.y));
  const maxY = Math.max(...shapePoints.map((point) => point.y));
  const footprintWidth = Math.abs(maxX - minX);
  const footprintDepth = Math.abs(maxY - minY);
  const footprintArea = Math.abs(
    shapePoints.reduce((area, point, index) => {
      const next = shapePoints[(index + 1) % shapePoints.length];
      return area + (point.x * next.y - next.x * point.y);
    }, 0) / 2
  );
  const defaultBuildingHeight = !isNaN(parseFloat(tags.height))
    ? parseFloat(tags.height)
    : extrudeSettings.depth;
  const defaultBuildingLevels = tags["building:levels"] || Math.round(extrudeSettings.depth / 2.2);
  const isSaiVidya =
    typeof tags.name === "string" &&
    tags.name.toLowerCase().includes("sai vidya");
  const buildingHeight = isSaiVidya ? 8.0 : defaultBuildingHeight;
  const buildingLevels = isSaiVidya ? 2 : defaultBuildingLevels;

  const edges = shapePoints.map((point, index) => {
    const next = shapePoints[(index + 1) % shapePoints.length];
    const dx = next.x - point.x;
    const dy = next.y - point.y;
    const length = Math.sqrt(dx * dx + dy * dy);
    const angle = Math.atan2(-dy, dx);
    return { point, next, length, angle, mid: new THREE.Vector2((point.x + next.x) / 2, (point.y + next.y) / 2) };
  });

  const entranceIndex = edges.reduce((best, edge, index) => {
    if (edge.length > best.length) {
      return { index, length: edge.length };
    }
    return best;
  }, { index: -1, length: 0 }).index;

  return (
    <group userData={{ exportToGLB: true }}>
      <mesh
        onPointerOver={(e) => {
          setHovered(true);
          e.stopPropagation();
        }}
        onPointerOut={(e) => {
          setHovered(false);
          e.stopPropagation();
        }}
        onClick={(e) => {
          setClicked(!clicked);
          e.stopPropagation();
          onSelect?.({
            tags,
            footprintWidth,
            footprintDepth,
            footprintArea,
            buildingHeight,
            buildingLevels,
          });
        }}
        rotation={[-Math.PI / 2, 0, 0]}
        castShadow
        receiveShadow
        userData={{ exportToGLB: true }}
      >
        <extrudeGeometry args={[shape, extrudeSettings]} />
        <meshStandardMaterial
          color={hovered || clicked ? "#dce7ff" : buildingColor}
          roughness={0.9}
          metalness={0.05}
          emissive={hovered || clicked ? "#eef2ff" : "#000000"}
          emissiveIntensity={hovered || clicked ? 0.04 : 0}
        />
        <Edges color="#4b5563" />
      </mesh>
      {edges.flatMap((edge, index) => {
        if (index === entranceIndex || edge.length < 8) return [];
        const windowHeight = Math.min(extrudeSettings.depth * 0.14, 0.35);
        const windowCount = Math.max(1, Math.min(3, Math.floor(edge.length / 2.5)));
        const windowWidth = Math.min((edge.length - (windowCount - 1) * 0.15) / windowCount, 2.2);
        return Array.from({ length: windowCount }).map((_, wi) => {
          const offset = (wi - (windowCount - 1) / 2) * (windowWidth + 0.18);
          return (
            <mesh
              key={`window-${index}-${wi}`}
              position={[edge.mid.x + Math.cos(edge.angle) * offset, extrudeSettings.depth * 0.55, -edge.mid.y - Math.sin(edge.angle) * offset]}
              rotation={[0, -edge.angle, 0]}
              castShadow={false}
              receiveShadow={false}
            >
              <boxGeometry args={[windowWidth, windowHeight, 0.04]} />
              <meshStandardMaterial color="#7cb5f7" roughness={0.3} metalness={0.6} transparent opacity={0.88} />
            </mesh>
          );
        });
      })}
      {entranceIndex >= 0 && (() => {
        const entrance = edges[entranceIndex];
        const doorWidth = Math.min(entrance.length * 0.35, 3.2);
        const doorHeight = Math.min(extrudeSettings.depth * 0.26, 1.25);
        const glassWidth = Math.min(entrance.length * 0.65, 5);
        const glassHeight = Math.min(extrudeSettings.depth * 0.3, 1.8);
        return (
          <group key="entrance">
            <mesh
              position={[entrance.mid.x, glassHeight / 2 + 0.1, -entrance.mid.y - 0.06]}
              rotation={[0, -entrance.angle, 0]}
              castShadow={false}
              receiveShadow={false}
            >
              <boxGeometry args={[glassWidth, glassHeight, 0.04]} />
              <meshStandardMaterial
                color="#2563eb"
                roughness={0.12}
                metalness={0.9}
                transparent
                opacity={0.75}
              />
            </mesh>
            <mesh
              position={[entrance.mid.x, doorHeight / 2, -entrance.mid.y]}
              rotation={[0, -entrance.angle, 0]}
              castShadow
              receiveShadow
            >
              <boxGeometry args={[doorWidth, doorHeight, 0.16]} />
              <meshStandardMaterial color="#2b2b33" roughness={0.35} metalness={0.05} />
            </mesh>
            <mesh
              position={[entrance.mid.x, doorHeight * 0.55, -entrance.mid.y + 0.095]}
              rotation={[0, -entrance.angle, 0]}
              castShadow={false}
            >
              <boxGeometry args={[doorWidth * 0.42, doorHeight * 0.4, 0.04]} />
              <meshStandardMaterial color="#7fb5f7" transparent opacity={0.92} />
            </mesh>
            <mesh
              position={[entrance.mid.x, doorHeight + 0.15, -entrance.mid.y]}
              rotation={[0, -entrance.angle, 0]}
              castShadow={false}
            >
              <boxGeometry args={[doorWidth * 0.62, 0.08, 0.12]} />
              <meshStandardMaterial color="#c7d2fe" />
            </mesh>
          </group>
        );
      })()}
      <mesh
        rotation={[-Math.PI / 2, 0, 0]}
        position={[0, extrudeSettings.depth + roofHeight / 2, 0]}
        castShadow
        receiveShadow
        userData={{ exportToGLB: true }}
      >
        <extrudeGeometry args={[shape, { ...extrudeSettings, depth: roofHeight }]} />
        <meshStandardMaterial color="#d9d9d9" roughness={0.9} metalness={0.2} />
      </mesh>
    </group>
  );
}

function Roads({ area }: { area: any }) {
  const [roads, setRoads] = useState<any[]>([]);
  if (!area || area.length < 2) return null;
  const refLat = (area[1].lat + area[0].lat) / 2;
  const refLng = (area[1].lng + area[0].lng) / 2;

  function project(lat: number, lng: number) {
    const x = (lng - refLng) * scale * Math.cos((refLat * Math.PI) / 180);
    const y = (lat - refLat) * scale;
    return new THREE.Vector2(x, y);
  }

  useEffect(() => {
    const south = area[1].lat;
    const west = area[1].lng;
    const north = area[0].lat;
    const east = area[0].lng;
    const query = `[out:json][timeout:25];(way["highway"](${south},${west},${north},${east}););out body geom;`;
    fetch("https://overpass-api.de/api/interpreter", {
      method: "POST",
      body: query,
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
    })
      .then((response) => response.json())
      .then((data) => {
        setRoads(data.elements);
      })
      .catch((err) => console.error(err));
  }, [area]);

  return (
    <>
      {roads.map((road, index) => {
        if (!road.geometry || road.geometry.length < 2) return null;

        const points = road.geometry.map((pt: any) => {
          const v = project(pt.lat, pt.lon);
          return new THREE.Vector3(v.x, 0.1, -v.y);
        });

        const lineGeometry: any = new THREE.BufferGeometry().setFromPoints(points);

        return (
          <Line
            points={points}
            color="#000000"
            lineWidth={1}
            userData={{ exportToGLB: true }}
          ></Line>
        );
      })}
    </>
  );
}

function MarkerModel({ marker }: { marker: any }) {
  const removeMarker = useAreaStore((state) => state.removeMarker);

  const colorMap: Record<string, string> = {
    enemy: "#ef4444",
    hospital: "#60a5fa",
    rescue: "#f59e0b",
    note: "#facc15",
    soldier: "#111827",
  };

  const color = colorMap[marker.type] || "#9ca3af";

  return (
    <group
      position={[marker.x, 0, marker.z]}
      onClick={(event) => {
        event.stopPropagation();
        removeMarker(marker.id);
      }}
      userData={{ exportToGLB: true }}
    >
      {marker.type === "enemy" && (
        <mesh castShadow receiveShadow>
          <octahedronGeometry args={[0.24, 0]} />
          <meshStandardMaterial color={color} />
        </mesh>
      )}
      {marker.type === "hospital" && (
        <>
          <mesh castShadow receiveShadow>
            <boxGeometry args={[0.24, 0.5, 0.24]} />
            <meshStandardMaterial color={color} />
          </mesh>
          <mesh position={[0, 0.02, 0]} castShadow receiveShadow>
            <boxGeometry args={[0.16, 0.12, 0.16]} />
            <meshStandardMaterial color="#ffffff" />
          </mesh>
        </>
      )}
      {marker.type === "rescue" && (
        <mesh castShadow receiveShadow>
          <tetrahedronGeometry args={[0.28, 0]} />
          <meshStandardMaterial color={color} />
        </mesh>
      )}
      {marker.type === "note" && (
        <>
          <mesh castShadow receiveShadow>
            <boxGeometry args={[0.22, 0.18, 0.03]} />
            <meshStandardMaterial color={color} />
          </mesh>
          <mesh position={[0, 0.03, 0.015]} castShadow receiveShadow>
            <boxGeometry args={[0.18, 0.12, 0.02]} />
            <meshStandardMaterial color="#fff7cc" />
          </mesh>
        </>
      )}
      {marker.type === "soldier" && (
        <group position={[0, 0.12, 0]}>
          <mesh position={[0, 0.25, 0]} castShadow receiveShadow>
            <sphereGeometry args={[0.18, 18, 18]} />
            <meshStandardMaterial color="#f9c74f" />
          </mesh>
          <mesh position={[0, -0.05, 0]} castShadow receiveShadow>
            <cylinderGeometry args={[0.12, 0.12, 0.44, 14]} />
            <meshStandardMaterial color="#1f2937" />
          </mesh>
          <mesh position={[0, -0.24, 0]} castShadow receiveShadow>
            <cylinderGeometry args={[0.16, 0.12, 0.08, 16]} />
            <meshStandardMaterial color="#374151" />
          </mesh>
          <mesh position={[0, -0.02, 0]} rotation={[Math.PI / 2, 0, 0]} castShadow receiveShadow>
            <cylinderGeometry args={[0.045, 0.045, 0.44, 10]} />
            <meshStandardMaterial color="#4b5563" />
          </mesh>
          <mesh position={[-0.2, 0.05, 0]} rotation={[0, 0, Math.PI / 10]} castShadow receiveShadow>
            <cylinderGeometry args={[0.045, 0.045, 0.34, 10]} />
            <meshStandardMaterial color="#1f2937" />
          </mesh>
          <mesh position={[0.2, 0.05, 0]} rotation={[0, 0, -Math.PI / 10]} castShadow receiveShadow>
            <cylinderGeometry args={[0.045, 0.045, 0.34, 10]} />
            <meshStandardMaterial color="#1f2937" />
          </mesh>
          <mesh position={[0, 0.55, 0]} castShadow receiveShadow>
            <coneGeometry args={[0.12, 0.22, 14]} />
            <meshStandardMaterial color="#d92626" />
          </mesh>
        </group>
      )}
      {marker.note && (
        <Html position={[0, 0.8, 0]} center>
          <div
            style={{
              background: "rgba(255,255,255,0.94)",
              borderRadius: "8px",
              padding: "4px 8px",
              fontSize: "11px",
              color: "#111827",
              border: "1px solid #d1d5db",
              whiteSpace: "nowrap",
              boxShadow: "0 2px 8px rgba(0,0,0,0.1)",
            }}
          >
            {marker.note}
          </div>
        </Html>
      )}
    </group>
  );
}

function Vegetation({
  areas,
  center,
  soldierPreview,
  onPreviewSoldier,
}: {
  areas: any[];
  center: any[];
  soldierPreview: { x: number; z: number } | null;
  onPreviewSoldier: (point: { x: number; z: number }) => void;
}) {
  if (!areas?.length || !center?.[0] || !center?.[1]) return null;

  const refLat = (center[1].lat + center[0].lat) / 2;
  const refLng = (center[1].lng + center[0].lng) / 2;
  const markers = useAreaStore((state) => state.markers);
  const selectedMarkerType = useAreaStore((state) => state.selectedMarkerType);
  const noteText = useAreaStore((state) => state.noteText);
  const addMarker = useAreaStore((state) => state.addMarker);
  const advanceMode = useAreaStore((state) => state.advanceMode);
  const advancePoints = useAreaStore((state) => state.advancePoints);
  const advanceColor = useAreaStore((state) => state.advanceColor);
  const filledShapes = useAreaStore((state) => state.filledShapes);
  const addAdvancePoint = useAreaStore((state) => state.addAdvancePoint);

  function project(lat: number, lng: number) {
    const x = (lng - refLng) * scale * Math.cos((refLat * Math.PI) / 180);
    const y = (lat - refLat) * scale;
    return new THREE.Vector2(x, y);
  }

  const terrainGeometry = useMemo(() => {
    const geometry = new THREE.PlaneGeometry(5000, 5000, 120, 120);
    const position = geometry.attributes.position as THREE.BufferAttribute;
    const temp = new THREE.Vector3();

    for (let i = 0; i < position.count; i += 1) {
      temp.fromBufferAttribute(position, i);
      const height =
        Math.sin(temp.x * 0.0012) * Math.cos(temp.y * 0.0009) * 9 +
        Math.cos((temp.x - temp.y) * 0.0005) * 4;
      position.setZ(i, height);
    }

    geometry.computeVertexNormals();
    return geometry;
  }, []);

  const areaPolygons = useMemo(
    () =>
      areas
        .filter((area: any) => area.geometry && area.geometry.length >= 3)
        .map((area: any) => {
          const shapePoints = area.geometry.map((pt: any) => project(pt.lat, pt.lng));
          if (!shapePoints[0].equals(shapePoints[shapePoints.length - 1])) {
            shapePoints.push(shapePoints[0]);
          }
          const outline = shapePoints.map((point) => new THREE.Vector3(point.x, 0.05, -point.y));
          return {
            shape: new THREE.Shape(shapePoints),
            outline,
          };
        }),
    [areas, refLat, refLng]
  );

  const allPoints = areas.flatMap((area: any) => (area.geometry || []).map((pt: any) => ({ lat: pt.lat, lng: pt.lng })));
  if (!allPoints.length) return null;

  const minLat = Math.min(...allPoints.map((pt) => pt.lat));
  const maxLat = Math.max(...allPoints.map((pt) => pt.lat));
  const minLng = Math.min(...allPoints.map((pt) => pt.lng));
  const maxLng = Math.max(...allPoints.map((pt) => pt.lng));

  const spanLat = Math.max(0.001, maxLat - minLat);
  const spanLng = Math.max(0.001, maxLng - minLng);
  const treeCount = Math.max(14, Math.min(36, Math.round(spanLat * spanLng * 18000)));

  const positions = Array.from({ length: treeCount }, (_, index) => {
    const lat = minLat + spanLat * (0.15 + (index / treeCount) * 0.7);
    const lng = minLng + spanLng * ((index * 0.618) % 1);
    const jitterLat = ((index * 37) % 7) / 7 - 0.5;
    const jitterLng = ((index * 29) % 5) / 5 - 0.5;
    const projected = project(lat + jitterLat * spanLat * 0.08, lng + jitterLng * spanLng * 0.08);
    return new THREE.Vector3(projected.x, 0, -projected.y);
  });

  const handlePlaceMarker = (event: any) => {
    if (!event?.point) return;
    event.stopPropagation();

    if (advanceMode) {
      addAdvancePoint({ x: event.point.x, z: event.point.z });
      return;
    }

    if (selectedMarkerType === "soldier") {
      onPreviewSoldier({ x: event.point.x, z: event.point.z });
      return;
    }

    addMarker({
      type: selectedMarkerType,
      x: event.point.x,
      z: event.point.z,
      note: noteText.trim() || undefined,
    });
  };

  const advanceShape = advancePoints.length >= 3 ? useMemo(() => {
    const shape = new THREE.Shape(
      advancePoints.map((point) => new THREE.Vector2(point.x, point.z))
    );
    return new THREE.ShapeGeometry(shape);
  }, [advancePoints]) : null;

  const savedShapeGeometries = useMemo(
    () =>
      filledShapes.map((shapeData) => {
        const shape = new THREE.Shape(
          shapeData.points.map((point) => new THREE.Vector2(point.x, point.z))
        );
        return {
          id: shapeData.id,
          color: shapeData.color,
          geometry: new THREE.ShapeGeometry(shape),
        };
      }),
    [filledShapes]
  );

  return (
    <group userData={{ exportToGLB: true }}>
      <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow position={[0, -0.12, 0]} onPointerDown={handlePlaceMarker} geometry={terrainGeometry}>
        <meshStandardMaterial color="#3e6c2f" roughness={0.92} metalness={0.04} />
      </mesh>

      {advanceMode && (
        <group>
          {advancePoints.map((point, index) => (
            <mesh key={`advance-point-${index}`} position={[point.x, 0.25, point.z]}>
              <sphereGeometry args={[0.32, 20, 20]} />
              <meshStandardMaterial color="#f59e0b" emissive="#fbbf24" emissiveIntensity={0.7} />
            </mesh>
          ))}

          {advancePoints.length > 1 && (
            <Line
              points={advancePoints.map((point) => [point.x, 0.12, point.z])}
              color="#f59e0b"
              lineWidth={2}
              dashed={false}
            />
          )}

          {advanceShape && (
            <mesh
              rotation={[-Math.PI / 2, 0, 0]}
              position={[0, 0.05, 0]}
              geometry={advanceShape}
            >
              <meshStandardMaterial color={advanceColor} opacity={0.4} transparent />
            </mesh>
          )}
        </group>
      )}

      {savedShapeGeometries.map((shapeDef) => (
        <mesh
          key={shapeDef.id}
          rotation={[-Math.PI / 2, 0, 0]}
          position={[0, 0.05, 0]}
          geometry={shapeDef.geometry}
        >
          <meshStandardMaterial color={shapeDef.color} opacity={0.45} transparent />
        </mesh>
      ))}

      {areaPolygons.map((area, index) => (
        <group key={index} userData={{ exportToGLB: true }}>
          <Line points={area.outline} color="#264d22" lineWidth={2} />
        </group>
      ))}

      {positions.map((position, index) => {
        const trunkHeight = 0.8 + (index % 3) * 0.25;
        const crownRadius = 0.45 + (index % 4) * 0.12;
        return (
          <group key={index} position={[position.x, 0, position.z]} userData={{ exportToGLB: true }}>
            <mesh position={[0, trunkHeight / 2, 0]} castShadow receiveShadow>
              <cylinderGeometry args={[0.08, 0.1, trunkHeight, 8]} />
              <meshStandardMaterial color="#7a4b2e" />
            </mesh>
            <mesh position={[0, trunkHeight + crownRadius * 0.7, 0]} castShadow receiveShadow>
              <coneGeometry args={[crownRadius, crownRadius * 1.5, 8]} />
              <meshStandardMaterial color="#2e8b57" />
            </mesh>
            <mesh position={[0, trunkHeight + crownRadius * 1.2, 0]} castShadow receiveShadow>
              <coneGeometry args={[crownRadius * 0.75, crownRadius * 1.15, 8]} />
              <meshStandardMaterial color="#3fa34a" />
            </mesh>
          </group>
        );
      })}
      {markers.map((marker) => (
        <MarkerModel key={marker.id} marker={marker} />
      ))}

      {soldierPreview && (
        <group position={[soldierPreview.x, 0.12, soldierPreview.z]} userData={{ exportToGLB: true }}>
          <mesh position={[0, 0.25, 0]} castShadow receiveShadow>
            <sphereGeometry args={[0.18, 18, 18]} />
            <meshStandardMaterial color="#f9c74f" opacity={0.8} transparent />
          </mesh>
          <mesh position={[0, -0.05, 0]} castShadow receiveShadow>
            <cylinderGeometry args={[0.12, 0.12, 0.44, 14]} />
            <meshStandardMaterial color="#1f2937" opacity={0.8} transparent />
          </mesh>
          <mesh position={[0, -0.24, 0]} castShadow receiveShadow>
            <cylinderGeometry args={[0.16, 0.12, 0.08, 16]} />
            <meshStandardMaterial color="#374151" opacity={0.8} transparent />
          </mesh>
        </group>
      )}
    </group>
  );
}

export function Export() {
  const { scene } = useThree();
  const action = useActionStore((state) => state.action);
  const fleetSpaceId = useActionStore((state) => state.fleetSpaceId);

  const exportType = useActionStore((state) => state.exportType);

  const setAction = useActionStore((state) => state.setAction);

  useEffect(() => {
    if (action === true) {
      setAction(false);
      exportGLB();
    }
  }, [action, setAction, scene]);

  const uploadFleet = async (blob) => {
    const formData = new FormData();

    formData.append("object", blob, "box3d.glb");
    formData.append("title", "New Object");
    formData.append("description", "");
    formData.append("spaceId", fleetSpaceId);

    await instanceFleet.post("space/file/mesh", formData, {
      headers: {
        "Content-Type": "multipart/form-data",
      },
    });
  };

  const exportGLB = () => {
    const exportRoot = new THREE.Group();
    scene.traverse((child) => {
      if (child.userData?.exportToGLB === true) {
        exportRoot.add(child.clone(true));
      }
    });
    const exporter = new GLTFExporter();
    const options = { binary: true, embedImages: true };
    exporter.parse(
      exportRoot,
      (result) => {
        if (result instanceof ArrayBuffer) {
          const blob = new Blob([result], { type: "model/gltf-binary" });

          if (exportType == "glb") {
            const link = document.createElement("a");
            link.style.display = "none";
            document.body.appendChild(link);
            link.href = URL.createObjectURL(blob);
            link.download = "scene.glb";
            link.click();
            document.body.removeChild(link);
          }

          if (exportType == "fleet") {
            uploadFleet(blob);
          }
        } else {
          console.error("GLB export failed: unexpected result", result);
        }
      },
      (error) => {
        console.error("An error occurred during export", error);
      },
      options
    );
  };
  return null;
}

export function Space() {
  const areas = useAreaStore((state) => state.areas);
  const [realCenter, setRealCenter] = useState<any>();
  const center = useAreaStore((state) => state.center);
  const refLat = (center[1].lat + center[0].lat) / 2;
  const refLng = (center[1].lng + center[0].lng) / 2;

  function project(lat: number, lng: number) {
    const x = (lng - refLng) * scale * Math.cos((refLat * Math.PI) / 180);
    const y = (lat - refLat) * scale;
    return new THREE.Vector2(x, y);
  }

  const areaData = () => {
    const result: Array<{
      shape: THREE.Shape;
      extrudeSettings: any;
      tags: any;
    }> = [];
    areas.forEach((bld: any) => {
      if (!bld.geometry || bld.geometry.length < 3) return;
      const shapePoints = bld.geometry.map((pt: any) => project(pt.lat, pt.lng));
      if (!shapePoints[0].equals(shapePoints[shapePoints.length - 1]))
        shapePoints.push(shapePoints[0]);
      const shape = new THREE.Shape(shapePoints);
      let heightValue = parseFloat(bld.tags.height || "");
      const heightLevels = parseFloat(bld.tags["building:levels"] || "");
      if (isNaN(heightValue)) heightValue = 10;
      if (!isNaN(heightLevels)) heightValue = heightLevels * 2.2;
      const extrudeSettings = {
        steps: 1,
        depth: heightValue,
        bevelEnabled: false,
      };
      result.push({ shape, extrudeSettings, tags: bld.tags });
    });
    return result;
  };

  useEffect(() => {
    setRealCenter(center);
  }, [areas]);

  const buildingsData = areaData();
  const [selectedBuilding, setSelectedBuilding] = useState<null | {
    tags: any;
    footprintWidth: number;
    footprintDepth: number;
    footprintArea: number;
    buildingHeight: number;
    buildingLevels: number;
  }>(null);
  const [soldierPreview, setSoldierPreview] = useState<{ x: number; z: number } | null>(null);
  const advanceMode = useAreaStore((state) => state.advanceMode);
  const advancePoints = useAreaStore((state) => state.advancePoints);
  const completeAdvanceShape = useAreaStore((state) => state.completeAdvanceShape);
  const clearAdvancePoints = useAreaStore((state) => state.clearAdvancePoints);
  const addMarker = useAreaStore((state) => state.addMarker);
  const noteText = useAreaStore((state) => state.noteText);

  const handleBuildingSelect = (building: any) => {
    setSelectedBuilding(building);
  };

  return (
    <div style={{ position: "relative", width: "100%", height: "100%" }}>
      <Canvas style={{ width: "100%", height: "100%" }} camera={{ fov: 90, near: 0.1, far: 7000 }} shadows>
        <ambientLight intensity={Math.PI / 2} />
        <spotLight position={[10, 10, 10]} angle={0.15} penumbra={1} decay={0} intensity={Math.PI} />
        {buildingsData.map((item, index) => (
          <Building
            key={index}
            shape={item.shape}
            extrudeSettings={item.extrudeSettings}
            tags={item.tags}
            onSelect={handleBuildingSelect}
          />
        ))}

        <Roads area={realCenter} />
        <Vegetation
          areas={areas}
          center={center}
          soldierPreview={soldierPreview}
          onPreviewSoldier={setSoldierPreview}
        />
        <pointLight position={[-10, -10, -10]} decay={0} intensity={Math.PI} />
        <Car />
        <Export />
        <Sky distance={450000} sunPosition={[0, 1, 0]} inclination={0.4} azimuth={0.3} />
        <Environment preset="sunset" />
      </Canvas>

      {soldierPreview && (
        <div
          style={{
            position: "absolute",
            left: 16,
            bottom: 16,
            maxWidth: 320,
            padding: "14px",
            background: "rgba(255,255,255,0.96)",
            borderRadius: "16px",
            boxShadow: "0 18px 40px rgba(15, 23, 42, 0.16)",
            color: "#111827",
            fontSize: "13px",
            lineHeight: 1.5,
            zIndex: 10,
          }}
        >
          <div style={{ fontSize: "15px", fontWeight: 700, marginBottom: "8px" }}>
            Place Soldier
          </div>
          <div style={{ marginBottom: "10px" }}>
            Click "Place" to drop the soldier here.
          </div>
          <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap" }}>
            <button
              style={{
                cursor: "pointer",
                padding: "0.65rem 0.85rem",
                borderRadius: "10px",
                border: "1px solid #d1d5db",
                background: "#ffffff",
                fontWeight: 600,
              }}
              onClick={() => {
                addMarker({
                  type: "soldier",
                  x: soldierPreview.x,
                  z: soldierPreview.z,
                  note: noteText.trim() || undefined,
                });
                setSoldierPreview(null);
              }}
            >
              Place
            </button>
            <button
              style={{
                cursor: "pointer",
                padding: "0.65rem 0.85rem",
                borderRadius: "10px",
                border: "1px solid #d1d5db",
                background: "#fef2f2",
                color: "#b91c1c",
                fontWeight: 600,
              }}
              onClick={() => setSoldierPreview(null)}
            >
              Cancel
            </button>
          </div>
        </div>
      )}

      <div
        style={{
          position: "absolute",
          top: 16,
          right: 16,
          maxWidth: 320,
          padding: "16px",
          background: "rgba(255,255,255,0.95)",
          borderRadius: "16px",
          boxShadow: "0 18px 40px rgba(15, 23, 42, 0.16)",
          color: "#111827",
          fontSize: "13px",
          lineHeight: 1.5,
          zIndex: 10,
        }}
      >
        <div style={{ fontSize: "16px", fontWeight: 700, marginBottom: "10px" }}>
          Building Info
        </div>
        {selectedBuilding ? (
          <div>
            <div style={{ marginBottom: "8px", fontWeight: 600 }}>{selectedBuilding.tags.name || "Unnamed Building"}</div>
            <div style={{ marginBottom: "6px" }}>
              <span style={{ fontWeight: 600 }}>Height:</span> {selectedBuilding.buildingHeight.toFixed(1)}m
            </div>
            <div style={{ marginBottom: "6px" }}>
              <span style={{ fontWeight: 600 }}>Width:</span> {selectedBuilding.footprintWidth.toFixed(1)}m
            </div>
            <div style={{ marginBottom: "6px" }}>
              <span style={{ fontWeight: 600 }}>Depth:</span> {selectedBuilding.footprintDepth.toFixed(1)}m
            </div>
            <div style={{ marginBottom: "6px" }}>
              <span style={{ fontWeight: 600 }}>Footprint Area:</span> {selectedBuilding.footprintArea.toFixed(1)} m²
            </div>
            <div style={{ marginBottom: "6px" }}>
              <span style={{ fontWeight: 600 }}>Floors:</span> {selectedBuilding.buildingLevels}
            </div>
            {(
              (selectedBuilding.tags && (selectedBuilding.tags.sai_vidya === "yes" || selectedBuilding.tags.svit === "yes")) ||
              (selectedBuilding.tags.name && selectedBuilding.tags.name.trim().toLowerCase() === "sai vidya institute")
            ) && (
              <div style={{ marginTop: "12px", padding: "10px", borderRadius: "10px", background: "rgba(245, 248, 255, 0.88)" }}>
                <div style={{ fontWeight: 600, marginBottom: "6px" }}>Sai Vidya Institute Details</div>
                <div>Number of floors: 2</div>
                <div>Basketball courts: 1</div>
                <div>Big ground in front of college</div>
                <div>Established in 2008</div>
              </div>
            )}
            <div style={{ marginTop: "12px" }}>
              <div style={{ fontWeight: 600, marginBottom: "6px" }}>Tags</div>
              <div style={{ maxHeight: "170px", overflowY: "auto", paddingRight: "4px" }}>
                {Object.entries(selectedBuilding.tags).map(([key, value]) => (
                  <div key={key} style={{ display: "flex", justifyContent: "space-between", marginBottom: "4px" }}>
                    <span style={{ color: "#4b5563" }}>{key}</span>
                    <span style={{ color: "#111827" }}>{String(value)}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ) : (
          <div>Select a building in the scene to view details here.</div>
        )}
      </div>

      {advanceMode && (
        <div
          style={{
            position: "absolute",
            left: 16,
            top: 16,
            maxWidth: 320,
            padding: "14px",
            background: "rgba(255,255,255,0.96)",
            borderRadius: "16px",
            boxShadow: "0 18px 40px rgba(15, 23, 42, 0.16)",
            color: "#111827",
            fontSize: "13px",
            lineHeight: 1.5,
            zIndex: 10,
          }}
        >
          <div style={{ fontSize: "15px", fontWeight: 700, marginBottom: "10px" }}>
            Advance Shape Mode
          </div>
          <div style={{ marginBottom: "8px" }}>
            Click on the terrain to place points. When you have 3 or more points, complete the shape.
          </div>
          <div style={{ display: "flex", gap: "0.5rem", flexWrap: "wrap" }}>
            <button
              style={{
                cursor: "pointer",
                padding: "0.65rem 0.85rem",
                borderRadius: "10px",
                border: "1px solid #d1d5db",
                background: "#ffffff",
                fontWeight: 600,
              }}
              onClick={completeAdvanceShape}
              disabled={advancePoints.length < 3}
            >
              Complete Shape
            </button>
            <button
              style={{
                cursor: "pointer",
                padding: "0.65rem 0.85rem",
                borderRadius: "10px",
                border: "1px solid #d1d5db",
                background: "#fef2f2",
                color: "#b91c1c",
                fontWeight: 600,
              }}
              onClick={clearAdvancePoints}
            >
              Cancel
            </button>
          </div>
          <div style={{ marginTop: "10px", fontSize: "12px", color: "#6b7280" }}>
            Points placed: {advancePoints.length}
          </div>
        </div>
      )}
    </div>
  );
}
