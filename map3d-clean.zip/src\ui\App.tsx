import { css, keyframes } from "@emotion/react";
import { Space } from "../three/Space";
import { FullscreenModal } from "../components/FullscreenModal";
import { Title } from "@/components/text/Title";
import { Description } from "@/components/text/Description";
import { Column } from "@/components/flex/Column";
import { MapComponent } from "@/components/map/SelectMap";
import { useEffect, useState } from "react";
import { UploadImages } from "@/components/UploadImages";
import { JobStatus } from "@/components/JobStatus";
import {
  Button,
  NextButton,
  PrevButton,
} from "@/components/button/BottomButton";
import { BuildingHeights, Building } from "@/components/map/Processing";
import { ChevronLeft, ChevronRight, Download, Loader2 } from "lucide-react";
import { useAreaStore } from "@/state/areaStore";
import { useActionStore } from "@/state/exportStore";
import { Modal } from "@/components/modal/Modal";
import { TopNav } from "@/components/nav/TopNav";
import { getCookie } from "@/utils/cookie";
import { Row } from "@/components/flex/Row";
import instanceFleet from "@/api/axios";

const IconSize = css({
  width: "14px",
  height: "14px",
});

const spinAnimation = keyframes`
from { transform: rotate(0deg); }
to { transform: rotate(360deg); }
`;

const pulseAnimation = keyframes`
0%, 100% { transform: translateY(0); opacity: 1; }
50% { transform: translateY(6px); opacity: 0.75; }
`;

function LandingScreen({ onContinue, onImagesSelected, imageCount, isUploading }: { onContinue: () => void; onImagesSelected?: (files: File[]) => void; imageCount: number; isUploading: boolean }) {
  return (
    <div
      css={css({
        position: "fixed",
        inset: 0,
        zIndex: 9998,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "rgba(4, 10, 22, 0.75)",
        backdropFilter: "blur(10px)",
        padding: "2rem",
      })}
    >
      <div
        css={css({
          textAlign: "center",
          color: "#ffffff",
          width: "100%",
          maxWidth: "52rem",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          gap: "1.25rem",
        })}
      >
        <div
          css={css({
            fontSize: "clamp(3rem, 6vw, 5rem)",
            fontWeight: 700,
            lineHeight: 1,
            letterSpacing: "-0.04em",
            textShadow: "0 20px 60px rgba(0,0,0,0.35)",
          })}
        >
          Explore the world in 3D
        </div>
        <div
          css={css({
            maxWidth: "40rem",
            color: "rgba(255, 255, 255, 0.82)",
            fontSize: "1.05rem",
            lineHeight: 1.8,
          })}
        >
          Start by selecting an area on the map, then generate a realistic 3D terrain export.
          Upload images here if you have them, and still choose your location on the map in the next step.
          The background stays in motion so you can feel the globe come alive.
        </div>

        {/* Image upload UI: client-side selection and preview */}
        <div css={css({ width: "100%", marginTop: "0.5rem" })}>
          <div css={css({ display: "flex", justifyContent: "center" })}>
            <UploadImages onSelect={(files) => onImagesSelected?.(files)} />
          </div>
        </div>

        <button
          css={css({
            border: "none",
            borderRadius: "999px",
            padding: "1rem 2rem",
            backgroundColor: "#ffffff",
            color: "#0f172a",
            fontWeight: 700,
            fontSize: "1rem",
            cursor: "pointer",
            boxShadow: "0 18px 50px rgba(0, 0, 0, 0.28)",
            transition: "transform 0.2s ease, background-color 0.2s ease",
            ":hover": {
              transform: "translateY(-2px)",
              backgroundColor: "#f8fafc",
            },
          })}
          onClick={onContinue}
        >
          Continue to map
        </button>
        <div css={css({ color: "rgba(255,255,255,0.8)", fontSize: "0.95rem", marginTop: "0.5rem" })}>
          {imageCount > 0
            ? isUploading
              ? `Uploading ${imageCount} photo${imageCount === 1 ? "" : "s"}...`
              : `${imageCount} photo${imageCount === 1 ? "" : "s"} selected. You can still pick the location on the map in the next step.`
            : "Select photos now or continue to choose a location on the map."}
        </div>
        <div
          css={css({
            display: "flex",
            flexDirection: "column",
            alignItems: "center",
            gap: "0.5rem",
            color: "rgba(255,255,255,0.72)",
            fontSize: "0.96rem",
            animation: `${pulseAnimation} 1.8s ease-in-out infinite`,
          })}
        >
          <span>Click to continue</span>
          <span css={css({ display: "inline-block", width: "0.75rem", height: "0.75rem", borderRadius: "999px", backgroundColor: "#10b981" })} />
        </div>
      </div>
    </div>
  );
}

function App() {
  const [isNextButtonDisabled, setIsNextButtonDisabled] = useState(true);
  const [areaData, setAreaData] = useState([]);
  const [steps, setSteps] = useState(["front", "processing"]);
  const [step, setStep] = useState(0);
  const [isWarnModal, setIsWarnModal] = useState(false);
  const [isExportModal, setIsExportModal] = useState(false);
  const [isFleetLogin, setIsFleetLogin] = useState(false);
  const [isFleetModal, setIsFleetModal] = useState(false);
  const [spaceList, setSpaceList] = useState([]);
  const [buildings, setBuildings] = useState<Building[]>([]);
  const [isFetchingBuildings, setIsFetchingBuildings] = useState(false);
  const [hasFetchedBuildings, setHasFetchedBuildings] = useState(false);
  const [uploadedFiles, setUploadedFiles] = useState<File[]>([]);
  const [jobId, setJobId] = useState<string | null>(null);
  const [, setJobStatus] = useState<string | null>(null);
  const [detailedStatus, setDetailedStatus] = useState<any | null>(null);
  const [isUploadingImages, setIsUploadingImages] = useState(false);
  const nextButtonDisabled = step === 0 ? false : isNextButtonDisabled || isFetchingBuildings;

  const setCenter = useAreaStore((state) => state.setCenter);
  const appendAreas = useAreaStore((state) => state.appendAreas);
  const setAction = useActionStore((state) => state.setAction);
  const setFleet = useActionStore((state) => state.setFleet);

  const checkIsBig = () => {
    const a = areaData[0].lat - areaData[1].lat;
    const b = areaData[0].lng - areaData[1].lng;

    console.log(a + b);

    if (a + b > 0.1) {
      return true;
    } else {
      return false;
    }
  };

  const exportFile = () => {
    setAction(true);
  };

  const exportFleet = () => {
    setAction(true);
  };

  const getFleetSpaces = async () => {
    const getSpace: any = await instanceFleet.get("space");

    setSpaceList([
      ...getSpace.data.spaces.map((item) => {
        return {
          ...item,
          key: item.id,
        };
      }),
    ]);
  };

  const putGlbOnFleetSpace = (spaceId) => {
    setFleet(spaceId, "fleet");
    setTimeout(() => {
      exportFleet();
    }, 100);
  };

  const loadFleetSpace = () => {
    getFleetSpaces();
    setIsFleetModal(true);
  };

  const checkFleetLogin = () => {
    try {
      const isCookie = getCookie("token");
      if (isCookie) {
        setIsFleetLogin(true);
      }
    } catch (error) {}
  };

  const handleDone = (data) => {
    setAreaData(data);
    setCenter(data);
    console.log(data, "AAEE");
    setIsNextButtonDisabled(false);
    setBuildings([]);
    setHasFetchedBuildings(false);
  };

  const handleRemove = () => {
    setAreaData([]);
    setIsNextButtonDisabled(true);
    setBuildings([]);
    setHasFetchedBuildings(false);
  };

  const requestBuildings = async () => {
    setIsFetchingBuildings(true);

    const south = areaData[1].lat;
    const west = areaData[1].lng;
    const north = areaData[0].lat;
    const east = areaData[0].lng;
    const query = `[out:json][timeout:25];(way["building"]( ${south},${west},${north},${east} );relation["building"]( ${south},${west},${north},${east} ););out body geom;`;
    try {
      const response = await fetch("https://overpass-api.de/api/interpreter", {
        method: "POST",
        body: query,
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
      });
      const data = await response.json();
      const blds: Building[] = data.elements.map((element) => ({
        id: element.id,
        tags: element.tags,
        geometry: element.geometry
          ? element.geometry.map((pt) => ({ lat: pt.lat, lng: pt.lon }))
          : undefined,
      }));
      setBuildings(blds);
      appendAreas(blds);
      setHasFetchedBuildings(true);
    } catch (error) {
      console.error("Error fetching building data:", error);
    } finally {
      setIsFetchingBuildings(false);
    }
  };

  const handleClickNextStep = async () => {
    if (step === 0) {
      setStep(1);
      return;
    }
    if (step === 1 && checkIsBig()) {
      setIsWarnModal(true);
      return false;
    }
    if (step === 2 && !hasFetchedBuildings) {
      await requestBuildings();
      return;
    }
    setStep(step + 1);
  };

  const handleClickPrevStep = () => {
    setStep(step - 1);
  };

  const handleClickExport = () => {
    setIsExportModal(true);
  };

  async function uploadJob(files: File[]) {
    if (!files || files.length === 0) return null;
    setIsUploadingImages(true);
    const fd = new FormData();
    files.forEach((f) => fd.append('images', f));
    try {
      const resp = await fetch('http://localhost:3000/api/jobs', { method: 'POST', body: fd });
      const json = await resp.json();
      return json.jobId;
    } catch (err) {
      console.error('Upload failed', err);
      return null;
    } finally {
      setIsUploadingImages(false);
    }
  }

  async function pollJob(id: string) {
    setJobId(id);
    setJobStatus('queued');
    const poll = setInterval(async () => {
      try {
        const res = await fetch(`http://localhost:3000/api/jobs/${id}/status`);
        if (!res.ok) throw new Error('status_failed');
        const j = await res.json();
        setJobStatus(j.status || 'unknown');
        // store the detailed status object for JobStatus component
        setDetailedStatus(j);
        if (j.status === 'failed') {
          clearInterval(poll);
        } else if (j.status === 'finished' || j.status === 'done' || j.status === 'success') {
          clearInterval(poll);
        }
      } catch (err) {
        console.error('poll err', err);
      }
    }, 2000);
  }

  async function handleLandingContinue() {
    setStep(1);
    if (uploadedFiles && uploadedFiles.length > 0) {
      const id = await uploadJob(uploadedFiles);
      if (id) {
        pollJob(id);
      }
    }
  }

  useEffect(() => {
    checkFleetLogin();
  }, []);

  return (
    <div css={css({ height: "100%", width: "100%" })}>
      {step !== 0 && <TopNav step={step} />}
      {step === 0 && (
        <LandingScreen
          onContinue={() => handleLandingContinue()}
          onImagesSelected={(files) => setUploadedFiles(files)}
          imageCount={uploadedFiles.length}
          isUploading={isUploadingImages}
        />
      )}
      <JobStatus jobId={jobId} statusData={detailedStatus} />

      <FullscreenModal isOpen={steps[step] == "front"}>
        <Column gap="1rem">
          <Column gap="0.5rem">
            <Title>Generate 3d map</Title>
            <Description>
              Tools to create 3D maps based on maps and export them in GLB
              format
            </Description>
          </Column>
          <MapComponent
            onRemove={handleRemove}
            onDone={handleDone}
          ></MapComponent>
        </Column>
      </FullscreenModal>

      <FullscreenModal isOpen={steps[step] == "processing"}>
        <Column gap="1rem">
          <Column gap="0.5rem">
            <Title>Processing</Title>
            <Description>
              Click Next Step to fetch building information. Once loaded, click
              Next Step again to view the 3D scene.
            </Description>

            <BuildingHeights
              buildings={buildings}
              loading={isFetchingBuildings}
            />
          </Column>
        </Column>
      </FullscreenModal>

      <PrevButton isShow={step > 0} onClick={handleClickPrevStep}>
        <ChevronLeft css={IconSize} /> Prev Step
      </PrevButton>

      <NextButton
        isShow={step > 0 && step !== 3}
        disabled={nextButtonDisabled}
        onClick={handleClickNextStep}
      >
        {isFetchingBuildings ? (
          <>
            <Loader2
              css={[
                IconSize,
                css({ animation: `${spinAnimation} 1s linear infinite` }),
              ]}
            />
            Fetching...
          </>
        ) : (
          <>
            {step === 0 ? "Start" : "Next Step"} <ChevronRight css={IconSize} />
          </>
        )}
      </NextButton>

      <NextButton isShow={step === 3} onClick={handleClickExport}>
        Export GLB <Download css={IconSize} />
      </NextButton>

      <Modal isOpen={isWarnModal} onClose={() => setIsWarnModal(false)}>
        <Column gap="0.5rem">
          <Title>The area is too big </Title>
          <Description>Do you want to proceed?</Description>
          <Button
            isShow={step != 2}
            disabled={isNextButtonDisabled}
            onClick={() => {
              setStep(step + 1);
              setIsWarnModal(false);
            }}
          >
            Next Step <ChevronRight css={IconSize} />
          </Button>
        </Column>
      </Modal>

      <Modal isOpen={isExportModal} onClose={() => setIsExportModal(false)}>
        <Column gap="0.5rem">
          <Title>Export</Title>

          <Row gap="0.5rem">
            <Button isShow={true} onClick={exportFile}>
              GLB Download <Download css={IconSize} />
            </Button>

            {/* {isFleetLogin ? (
              <Button isShow={true} onClick={loadFleetSpace}>
                Fleet Interlock
              </Button>
            ) : (
              <Button
                isShow={true}
                onClick={() => window.open("https://fleet.im/auth")}
              >
                Fleet Login
              </Button>
            )} */}
          </Row>
        </Column>
      </Modal>

      <Modal isOpen={isFleetModal} onClose={() => setIsFleetModal(false)}>
        <Column gap="0.5rem">
          <Title>Select Fleet Space</Title>
          {spaceList.map((item, index) => (
            <Button isShow={true} onClick={() => putGlbOnFleetSpace(item.id)}>
              {item.title}
            </Button>
          ))}
        </Column>
      </Modal>

      <Space></Space>
    </div>
  );
}

export default App;
